package  com.example.test

data class User(
    val id: Int,
    val name: String,
    val description: String
)